﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using StateManagement.Models;

namespace StateManagement.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            Customer customer = new Customer() { CustomerId = 19320, ContactName = "Anjala Johns", City = "New York" };
            return View(customer);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        [ActionName("Products")]
        public ActionResult SearchProduct(string category,int productid,int page)
        {
            return View();
        }
        public ActionResult CustomerProfile()
        {
            Customer customer = new Customer() { CustomerId = 19320, ContactName = "Anjala Johns", City = "New York" };
            HttpCookie profile = new HttpCookie("CustomerProfile");
            profile.Values.Add("CustomerId", customer.CustomerId.ToString());
            profile.Values.Add("ContactName", customer.ContactName);
            profile.Values.Add("City", customer.City);
            profile.Expires = DateTime.Now.AddMinutes(20);
            Response.AppendCookie(profile);
            return View();
        }
        public ActionResult ReadProfile()
        {
            return View();
        }
    }
}